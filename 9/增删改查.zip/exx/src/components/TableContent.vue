<template>
    <div class="content">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>姓名</th>
                    <th>年龄</th>
                    <th>性别</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(item,index) in list" :key="index">
                    <td>{{ index+1 }}</td>
                    <td>{{ item.name }}</td>
                    <td>{{ item.age }}</td>
                    <td>{{ item.sex }}</td>
                    <td>
                        <button @click="open(index)">编辑</button>
                        <button @click="remove(index)">删除</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>


<script>
export default {
    props: ["list"],
    methods: {
        remove(index) {
            // 调用自定义事件fn
            this.$emit("fn", index);
        },
        open(index) {
            // 调用自定义事件fn
            this.$emit("fn1",index);
        }
    }
};
</script>


<style lang="scss" scoped>
.content {
    width: 100%;
    table {
        width: 100%;
        text-align: center;
        border-collapse: collapse;
        tbody {
            tr {
                height: 46px;
                &:nth-child(even) {
                    background: skyblue;
                }
                &:nth-child(odd) {
                    background: tomato;
                }
                th,
                td {
                    border: 1px solid #ccc;
                }
            }
        }
    }
}
</style>