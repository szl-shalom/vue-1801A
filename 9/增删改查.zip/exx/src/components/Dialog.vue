<template>
    <div class="dialog">
        <div class="content">
            <p>姓名</p>
            <input type="text" v-model="name" />
            <p>年龄</p>
            <input type="text" v-model="age" />
            <p>性别</p>
            <input type="text" v-model="sex" />
            <p>
                <button @click="submit">提交</button>
                <button>取消</button>
            </p>
        </div>
    </div>
</template>


<script>
export default {
    props: {
        obj: {
            default() {
                return {};
            }
        }
    },
    created() {
        this.name = this.obj.name;
        this.age = this.obj.age;
        this.sex = this.obj.sex;
    },
    data() {
        return {
            name: "",
            age: "",
            sex: ""
        };
    },
    methods: {
        submit() {
            // 触发fn2事件的时候 将数据传入
            this.$emit("fn2", this.name, this.age, this.sex);
        }
    }
};
</script>


<style lang="scss" scoped>
.dialog {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    .content {
        position: fixed;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        background: #fff;
        padding: 20px;
        width: 300px;
        input {
            border: 1px solid #ccc;
        }
    }
}
</style>


