<template>
    <div id="app">
        <div class="header">
            <button @click="add">新增</button>
            <input type="text" placeholder="模糊搜索" v-model="val" />
        </div>
        <table-content :list="arr" @fn="del" @fn1="openDialog" />
        <dialog-content v-if="isShow" :obj="list[ind]" @fn2="changeData" />
    </div>
</template>

<script>
import Axios from "axios";

// 引入组件
import TableContent from "./components/TableContent";
import DialogContent from "./components/Dialog";
export default {
    // 注册组件
    components: {
        TableContent,
        DialogContent
    },
    // 数据
    data() {
        return {
            // 控制弹框是否显示
            isShow: false,
            // 模拟数据
            list: [],
            // 当前操作数据的下标
            ind: -1,
            // 设置新增还是编辑功能
            flag: true,
            // 模糊搜索数据
            val: ""
        };
    },
    created() {
        Axios.get("/api/list").then(res => {
            this.list = res.data;
        });
    },
    methods: {
        del(index) {
            this.list.splice(index, 1);
        },
        openDialog(index) {
            // 打开弹框
            this.isShow = true;
            // 修改当前的下标
            this.ind = index;
            // 编辑
            this.flag = true;
        },
        changeData(name, age, sex) {
            // 编辑
            if (this.flag) {
                // 修改数据
                this.list[this.ind].name = name;
                this.list[this.ind].age = age;
                this.list[this.ind].sex = sex;
            } else {
                // 新增
                this.list.push({
                    name,
                    age,
                    sex
                });
            }

            // 注意:如果直接修改对象本身的地址
            // 需要使用this.$set(数据，下标，修改之后的数据)
            // this.$set(this.list, this.ind, { name: name, age: age, sex: sex });
            // 关闭弹框
            this.isShow = false;
        },
        add() {
            this.isShow = true; //打开弹框
            this.ind = -1;
            this.flag = false; //新增
        }
    },
    computed: {
        arr() {
            return this.list.filter(item => item.name.includes(this.val));
        }
    }
};
</script>

<style lang="scss">
#app {
    width: 500px;
    margin: auto;
    .header {
        display: flex;
        justify-content: space-between;
    }
}
</style>
