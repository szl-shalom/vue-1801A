module.exports = {
    // lintOnSave: false,
    devServer: {
        before(app) {
            app.get("/api/list", (req, res) => {
                res.json([
                    {
                        name: "张三",
                        age: 18,
                        sex: "男"
                    },
                    {
                        name: "静静",
                        age: 18,
                        sex: "女"
                    },
                    {
                        name: "王五",
                        age: 26,
                        sex: "男"
                    },
                    {
                        name: "慧慧",
                        age: 22,
                        sex: "女"
                    }
                ])
            })
        }
    }
}